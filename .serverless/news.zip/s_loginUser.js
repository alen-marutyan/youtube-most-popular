
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'marutyan21',
  applicationName: 'youtube-most-popular',
  appUid: 'B1N69xd71yKdhySbTJ',
  orgUid: '79cef5ad-943d-45fe-b4f8-68812c46c1a8',
  deploymentUid: 'bce926df-a912-497e-8378-0f2d9d809381',
  serviceName: 'news',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'news-dev-loginUser', timeout: 6 };

try {
  const userHandler = require('./dist/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}